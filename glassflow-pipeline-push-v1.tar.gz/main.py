import argparse
import itertools
import logging
import os
import sys
from pathlib import Path

from yaml import safe_load

from glassflow import GlassFlowClient
from glassflow import Pipeline as GlassFlowPipeline
from models import Pipeline

logging.basicConfig(stream=sys.stdout, level=logging.INFO, format="%(message)s")
log = logging.getLogger(__name__)


def load_yaml_file(file):
    """Loads Pipeline YAML file"""
    # Load YAML
    with open(file) as f:
        yaml_data = safe_load(f)

    return Pipeline(**yaml_data)


def yaml_file_to_pipeline(
    yaml_path: Path, personal_access_token: str
) -> GlassFlowPipeline:
    """
    Converts a Pipeline YAML file into GlassFlow SDK Pipeline
    """
    yaml_file_dir = yaml_path.parent
    p = load_yaml_file(yaml_path)

    # We have one source, transformer and sink components
    source = [c for c in p.components if c.type == "source"][0]
    transformer = [c for c in p.components if c.type == "transformer"][0]
    sink = [c for c in p.components if c.type == "sink"][0]

    if transformer.requirements is not None:
        if transformer.requirements.value is not None:
            requirements = transformer.requirements.value
        else:
            with open(yaml_file_dir / transformer.requirements.path) as f:
                requirements = f.read()
    else:
        requirements = None

    if transformer.transformation.path is not None:
        transform = str(yaml_file_dir / transformer.transformation.path)
    else:
        transform = str(yaml_file_dir / "handler.py")
        with open(transform, "w") as f:
            f.write(transformer.transformation.value)

    pipeline_id = str(p.pipeline_id) if p.pipeline_id is not None else None
    env_vars = [e.model_dump(exclude_none=True) for e in transformer.env_vars]

    # TODO: Handle source and sink config_secret_ref
    # TODO: Handle env_var value_secret_ref
    return GlassFlowPipeline(
        personal_access_token=personal_access_token,
        id=pipeline_id,
        name=p.name,
        space_id=p.space_id.__str__(),
        env_vars=env_vars,
        transformation_file=transform,
        requirements=requirements,
        sink_kind=sink.kind,
        sink_config=sink.config,
        source_kind=source.kind,
        source_config=source.config,
    )


def get_yaml_files_with_changes(pipelines_dir: Path, files: list[Path]) -> set[Path]:
    """
    Given a list of pipeline file (`.yaml`, `.yml`, `.py` or
    `requirements.txt`) it returns the pipeline YAML files that
    the files belong to.
    """
    pipeline_2_files = map_yaml_to_files(pipelines_dir)

    pipelines_changed = set()
    for file in files:
        if file.suffix in [".yaml", ".yml"]:
            pipelines_changed.add(file)
        elif file.suffix == ".py" or file.name == "requirements.txt":
            for k in pipeline_2_files:
                if file in pipeline_2_files[k]:
                    pipelines_changed.add(k)
        else:
            continue

    return pipelines_changed


def map_yaml_to_files(path: Path) -> dict[Path, list[Path]]:
    """Maps Pipeline YAML files to .py and requirements.txt files"""
    yml_files = itertools.chain(path.rglob("*.yaml"), path.rglob("*.yml"))
    mapping = {}
    for file in yml_files:
        mapping[file] = []
        for c in load_yaml_file(file).components:
            if c.type == "transformer":
                transformer = c
                break
        else:
            continue

        if transformer.requirements.path is not None:
            path = file.parent / transformer.requirements.path
            mapping[file].append(path)

        if transformer.transformation.path is not None:
            path = file.parent / transformer.transformation.path
            mapping[file].append(path)
    return mapping


def add_pipeline_id_to_yaml(yaml_path: Path, pipeline_id: str):
    """Prepend the pipeline id to the yaml file"""
    with open(yaml_path, "r+") as f:
        content = f.read()
        f.seek(0, 0)
        f.write(f"pipeline_id: {pipeline_id}" + "\n" + content)


def set_outputs(outputs: dict):
    """Write outputs to GITHUB_OUTPUT environment variable"""
    for k, v in outputs.items():
        with open(os.environ["GITHUB_OUTPUT"], 'a') as fh:
            fh.write(f"{k}={v}\n")


def generate_outputs(
    changed_pipelines: list[GlassFlowPipeline],
    deleted_pipelines: list[GlassFlowPipeline],
):
    """Returns a dictionary of changes that will be applied"""
    to_create = len([p for p in changed_pipelines if p.id is None])
    to_update = len(changed_pipelines) - to_create
    to_update_ids = " , ".join([p.id for p in changed_pipelines if p.id is not None])
    to_delete = len(deleted_pipelines)
    to_delete_ids = " , ".join([p.id for p in deleted_pipelines])

    log.info(
        f"""
Expected changes on your GlassFlow pipelines:
\t‣ Create {to_create} pipelines
\t‣ Update {to_update} pipelines {"" if to_update == 0 else f'(IDs: {to_update_ids})'}
\t‣ Delete {to_delete} pipelines {"" if to_update == 0 else f'(IDs: {to_delete_ids})'}
        """
    )
    set_outputs({
        "to-create-count": to_create,
        "to-update-count": to_update,
        "to-update-ids": to_update_ids,
        "to-delete-count": to_delete,
        "to-delete-ids": to_delete_ids,
    })


def delete_pipelines(files_deleted: list[Path], client: GlassFlowClient):
    for file in files_deleted:
        if file.suffix in [".yaml", ".yml"]:
            p = yaml_file_to_pipeline(
                yaml_path=file, personal_access_token=client.personal_access_token
            )
            p.delete()
            log.info(f"Deleted pipeline {p.id}")


def push_to_cloud(
    files_changed: list[Path],
    files_deleted: list[Path],
    pipelines_dir: Path,
    client: GlassFlowClient,
    dry_run: bool = False,
):
    if files_deleted is not None:
        deleted_pipelines = [
            yaml_file_to_pipeline(f, client.personal_access_token)
            for f in files_deleted
            if f.suffix in [".yaml", ".yml"]
        ]
    else:
        deleted_pipelines = []

    if files_changed is not None:
        yaml_files_to_update = get_yaml_files_with_changes(
            pipelines_dir=pipelines_dir, files=files_changed
        )
        changed_pipelines = [
            yaml_file_to_pipeline(yaml_file, client.personal_access_token)
            for yaml_file in yaml_files_to_update
        ]
    else:
        yaml_files_to_update = []
        changed_pipelines = []

    generate_outputs(changed_pipelines, deleted_pipelines)
    if dry_run:
        log.info("This is a dry run. No changes will be applied.")
        exit(0)

    for pipeline, yaml_file in zip(changed_pipelines, yaml_files_to_update):
        if pipeline.id is None:
            # Create pipeline
            new_pipeline = pipeline.create()
            add_pipeline_id_to_yaml(yaml_file, new_pipeline.id)
        else:
            # Update pipeline
            existing_pipeline = client.get_pipeline(pipeline.id)
            existing_pipeline.update(
                name=pipeline.name,
                transformation_file=pipeline.transformation_file,
                requirements=pipeline.requirements,
                sink_kind=pipeline.sink_kind,
                sink_config=pipeline.sink_config,
                source_kind=pipeline.source_kind,
                source_config=pipeline.source_config,
                env_vars=pipeline.env_vars,
            )


def main():
    parser = argparse.ArgumentParser("Push pipelines configuration to GlassFlow cloud")
    parser.add_argument(
        "-d",
        "--files-deleted",
        help="List of files that were deleted (`.yaml`, `.yml`, `.py` or "
        "`requirements.txt`) to sync to GlassFlow.",
        type=Path,
        nargs="+",
    )
    parser.add_argument(
        "-a",
        "--files-changed",
        help="List of files with changes (`.yaml`, `.yml`, `.py` or "
        "`requirements.txt`) to sync to GlassFlow.",
        type=Path,
        nargs="+",
    )
    parser.add_argument(
        "--pipelines-dir",
        help="Path to directory with your GlassFlow pipelines.",
        type=Path,
        default="pipelines/",
    )
    parser.add_argument(
        "-t",
        "--personal-access-token",
        help="GlassFlow Personal Access Token.",
        type=str,
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        required=False,
        help="If set to True, no changes will be push to GlassFlow.",
    )
    args = parser.parse_args()

    client = GlassFlowClient(personal_access_token=args.personal_access_token)
    push_to_cloud(
        files_deleted=args.files_deleted,
        files_changed=args.files_changed,
        pipelines_dir=args.pipelines_dir,
        client=client,
        dry_run=args.dry_run,
    )


if __name__ == "__main__":
    main()
